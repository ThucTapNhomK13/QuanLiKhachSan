﻿namespace GUI
{
    partial class Form_QuanLiKhachHang
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.metroLabel1 = new MetroFramework.Controls.MetroLabel();
            this.metroButton1 = new MetroFramework.Controls.MetroButton();
            this.metroLabel2 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel3 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel4 = new MetroFramework.Controls.MetroLabel();
            this.txtClassroomId = new MetroFramework.Controls.MetroTextBox();
            this.metroLabel5 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel6 = new MetroFramework.Controls.MetroLabel();
            this.metroButton2 = new MetroFramework.Controls.MetroButton();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.metroLabel7 = new MetroFramework.Controls.MetroLabel();
            this.rdbFemale = new MetroFramework.Controls.MetroRadioButton();
            this.rdbMale = new MetroFramework.Controls.MetroRadioButton();
            this.metroLabel8 = new MetroFramework.Controls.MetroLabel();
            this.txtName = new MetroFramework.Controls.MetroTextBox();
            this.txtPeopleId = new MetroFramework.Controls.MetroTextBox();
            this.txtPayments = new MetroFramework.Controls.MetroTextBox();
            this.txtTel = new MetroFramework.Controls.MetroTextBox();
            this.dtpGiveBack = new MetroFramework.Controls.MetroDateTime();
            this.dtpOrder = new MetroFramework.Controls.MetroDateTime();
            this.metroLabel9 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel10 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel11 = new MetroFramework.Controls.MetroLabel();
            this.cmbService = new System.Windows.Forms.ComboBox();
            this.cmbServiceUsed = new System.Windows.Forms.ComboBox();
            this.btnOrder = new MetroFramework.Controls.MetroButton();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // metroLabel1
            // 
            this.metroLabel1.AutoSize = true;
            this.metroLabel1.Location = new System.Drawing.Point(56, 80);
            this.metroLabel1.Name = "metroLabel1";
            this.metroLabel1.Size = new System.Drawing.Size(48, 19);
            this.metroLabel1.TabIndex = 0;
            this.metroLabel1.Text = "Họ tên";
            // 
            // metroButton1
            // 
            this.metroButton1.Location = new System.Drawing.Point(624, 545);
            this.metroButton1.Name = "metroButton1";
            this.metroButton1.Size = new System.Drawing.Size(102, 23);
            this.metroButton1.TabIndex = 2;
            this.metroButton1.Text = "Xóa";
            this.metroButton1.UseSelectable = true;
            this.metroButton1.Click += new System.EventHandler(this.metroButton1_Click);
            // 
            // metroLabel2
            // 
            this.metroLabel2.AutoSize = true;
            this.metroLabel2.Location = new System.Drawing.Point(56, 124);
            this.metroLabel2.Name = "metroLabel2";
            this.metroLabel2.Size = new System.Drawing.Size(162, 19);
            this.metroLabel2.TabIndex = 0;
            this.metroLabel2.Text = "Chứng minh thư nhân dân";
            // 
            // metroLabel3
            // 
            this.metroLabel3.AutoSize = true;
            this.metroLabel3.Location = new System.Drawing.Point(442, 84);
            this.metroLabel3.Name = "metroLabel3";
            this.metroLabel3.Size = new System.Drawing.Size(86, 19);
            this.metroLabel3.TabIndex = 0;
            this.metroLabel3.Text = "Số điện thoại";
            // 
            // metroLabel4
            // 
            this.metroLabel4.AutoSize = true;
            this.metroLabel4.Location = new System.Drawing.Point(442, 124);
            this.metroLabel4.Name = "metroLabel4";
            this.metroLabel4.Size = new System.Drawing.Size(70, 19);
            this.metroLabel4.TabIndex = 0;
            this.metroLabel4.Text = "Mã phòng";
            // 
            // txtClassroomId
            // 
            // 
            // 
            // 
            this.txtClassroomId.CustomButton.Image = null;
            this.txtClassroomId.CustomButton.Location = new System.Drawing.Point(143, 1);
            this.txtClassroomId.CustomButton.Name = "";
            this.txtClassroomId.CustomButton.Size = new System.Drawing.Size(21, 21);
            this.txtClassroomId.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.txtClassroomId.CustomButton.TabIndex = 1;
            this.txtClassroomId.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.txtClassroomId.CustomButton.UseSelectable = true;
            this.txtClassroomId.CustomButton.Visible = false;
            this.txtClassroomId.Lines = new string[0];
            this.txtClassroomId.Location = new System.Drawing.Point(561, 120);
            this.txtClassroomId.MaxLength = 32767;
            this.txtClassroomId.Name = "txtClassroomId";
            this.txtClassroomId.PasswordChar = '\0';
            this.txtClassroomId.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.txtClassroomId.SelectedText = "";
            this.txtClassroomId.SelectionLength = 0;
            this.txtClassroomId.SelectionStart = 0;
            this.txtClassroomId.ShortcutsEnabled = true;
            this.txtClassroomId.Size = new System.Drawing.Size(165, 23);
            this.txtClassroomId.TabIndex = 1;
            this.txtClassroomId.UseSelectable = true;
            this.txtClassroomId.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.txtClassroomId.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // metroLabel5
            // 
            this.metroLabel5.AutoSize = true;
            this.metroLabel5.Location = new System.Drawing.Point(56, 219);
            this.metroLabel5.Name = "metroLabel5";
            this.metroLabel5.Size = new System.Drawing.Size(102, 19);
            this.metroLabel5.TabIndex = 0;
            this.metroLabel5.Text = "Ngày trả phòng";
            // 
            // metroLabel6
            // 
            this.metroLabel6.AutoSize = true;
            this.metroLabel6.Location = new System.Drawing.Point(442, 219);
            this.metroLabel6.Name = "metroLabel6";
            this.metroLabel6.Size = new System.Drawing.Size(91, 19);
            this.metroLabel6.TabIndex = 0;
            this.metroLabel6.Text = "Đã thanh toán";
            // 
            // metroButton2
            // 
            this.metroButton2.Location = new System.Drawing.Point(489, 545);
            this.metroButton2.Name = "metroButton2";
            this.metroButton2.Size = new System.Drawing.Size(109, 23);
            this.metroButton2.TabIndex = 2;
            this.metroButton2.Text = "Sửa";
            this.metroButton2.UseSelectable = true;
            this.metroButton2.Click += new System.EventHandler(this.metroButton2_Click);
            // 
            // dataGridView1
            // 
            this.dataGridView1.BackgroundColor = System.Drawing.SystemColors.ButtonHighlight;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.GridColor = System.Drawing.SystemColors.ButtonHighlight;
            this.dataGridView1.Location = new System.Drawing.Point(56, 340);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(670, 199);
            this.dataGridView1.TabIndex = 3;
            this.dataGridView1.Click += new System.EventHandler(this.dataGridView1_Click);
            // 
            // metroLabel7
            // 
            this.metroLabel7.AutoSize = true;
            this.metroLabel7.Location = new System.Drawing.Point(56, 318);
            this.metroLabel7.Name = "metroLabel7";
            this.metroLabel7.Size = new System.Drawing.Size(138, 19);
            this.metroLabel7.TabIndex = 0;
            this.metroLabel7.Text = "Danh sách khách hàng";
            // 
            // rdbFemale
            // 
            this.rdbFemale.AutoSize = true;
            this.rdbFemale.Location = new System.Drawing.Point(673, 175);
            this.rdbFemale.Name = "rdbFemale";
            this.rdbFemale.Size = new System.Drawing.Size(39, 15);
            this.rdbFemale.TabIndex = 6;
            this.rdbFemale.Text = "Nữ";
            this.rdbFemale.UseSelectable = true;
            // 
            // rdbMale
            // 
            this.rdbMale.AutoSize = true;
            this.rdbMale.Location = new System.Drawing.Point(561, 175);
            this.rdbMale.Name = "rdbMale";
            this.rdbMale.Size = new System.Drawing.Size(49, 15);
            this.rdbMale.TabIndex = 5;
            this.rdbMale.Text = "Nam";
            this.rdbMale.UseSelectable = true;
            // 
            // metroLabel8
            // 
            this.metroLabel8.AutoSize = true;
            this.metroLabel8.Location = new System.Drawing.Point(441, 171);
            this.metroLabel8.Name = "metroLabel8";
            this.metroLabel8.Size = new System.Drawing.Size(57, 19);
            this.metroLabel8.TabIndex = 4;
            this.metroLabel8.Text = "Giới tính";
            // 
            // txtName
            // 
            // 
            // 
            // 
            this.txtName.CustomButton.Image = null;
            this.txtName.CustomButton.Location = new System.Drawing.Point(158, 1);
            this.txtName.CustomButton.Name = "";
            this.txtName.CustomButton.Size = new System.Drawing.Size(21, 21);
            this.txtName.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.txtName.CustomButton.TabIndex = 1;
            this.txtName.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.txtName.CustomButton.UseSelectable = true;
            this.txtName.CustomButton.Visible = false;
            this.txtName.Lines = new string[0];
            this.txtName.Location = new System.Drawing.Point(224, 76);
            this.txtName.MaxLength = 32767;
            this.txtName.Name = "txtName";
            this.txtName.PasswordChar = '\0';
            this.txtName.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.txtName.SelectedText = "";
            this.txtName.SelectionLength = 0;
            this.txtName.SelectionStart = 0;
            this.txtName.ShortcutsEnabled = true;
            this.txtName.Size = new System.Drawing.Size(180, 23);
            this.txtName.TabIndex = 7;
            this.txtName.UseSelectable = true;
            this.txtName.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.txtName.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // txtPeopleId
            // 
            // 
            // 
            // 
            this.txtPeopleId.CustomButton.Image = null;
            this.txtPeopleId.CustomButton.Location = new System.Drawing.Point(158, 1);
            this.txtPeopleId.CustomButton.Name = "";
            this.txtPeopleId.CustomButton.Size = new System.Drawing.Size(21, 21);
            this.txtPeopleId.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.txtPeopleId.CustomButton.TabIndex = 1;
            this.txtPeopleId.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.txtPeopleId.CustomButton.UseSelectable = true;
            this.txtPeopleId.CustomButton.Visible = false;
            this.txtPeopleId.Lines = new string[0];
            this.txtPeopleId.Location = new System.Drawing.Point(224, 120);
            this.txtPeopleId.MaxLength = 32767;
            this.txtPeopleId.Name = "txtPeopleId";
            this.txtPeopleId.PasswordChar = '\0';
            this.txtPeopleId.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.txtPeopleId.SelectedText = "";
            this.txtPeopleId.SelectionLength = 0;
            this.txtPeopleId.SelectionStart = 0;
            this.txtPeopleId.ShortcutsEnabled = true;
            this.txtPeopleId.Size = new System.Drawing.Size(180, 23);
            this.txtPeopleId.TabIndex = 8;
            this.txtPeopleId.UseSelectable = true;
            this.txtPeopleId.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.txtPeopleId.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // txtPayments
            // 
            // 
            // 
            // 
            this.txtPayments.CustomButton.Image = null;
            this.txtPayments.CustomButton.Location = new System.Drawing.Point(143, 1);
            this.txtPayments.CustomButton.Name = "";
            this.txtPayments.CustomButton.Size = new System.Drawing.Size(21, 21);
            this.txtPayments.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.txtPayments.CustomButton.TabIndex = 1;
            this.txtPayments.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.txtPayments.CustomButton.UseSelectable = true;
            this.txtPayments.CustomButton.Visible = false;
            this.txtPayments.Lines = new string[0];
            this.txtPayments.Location = new System.Drawing.Point(561, 215);
            this.txtPayments.MaxLength = 32767;
            this.txtPayments.Name = "txtPayments";
            this.txtPayments.PasswordChar = '\0';
            this.txtPayments.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.txtPayments.SelectedText = "";
            this.txtPayments.SelectionLength = 0;
            this.txtPayments.SelectionStart = 0;
            this.txtPayments.ShortcutsEnabled = true;
            this.txtPayments.Size = new System.Drawing.Size(165, 23);
            this.txtPayments.TabIndex = 9;
            this.txtPayments.UseSelectable = true;
            this.txtPayments.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.txtPayments.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // txtTel
            // 
            // 
            // 
            // 
            this.txtTel.CustomButton.Image = null;
            this.txtTel.CustomButton.Location = new System.Drawing.Point(143, 1);
            this.txtTel.CustomButton.Name = "";
            this.txtTel.CustomButton.Size = new System.Drawing.Size(21, 21);
            this.txtTel.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.txtTel.CustomButton.TabIndex = 1;
            this.txtTel.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.txtTel.CustomButton.UseSelectable = true;
            this.txtTel.CustomButton.Visible = false;
            this.txtTel.Lines = new string[0];
            this.txtTel.Location = new System.Drawing.Point(561, 76);
            this.txtTel.MaxLength = 32767;
            this.txtTel.Name = "txtTel";
            this.txtTel.PasswordChar = '\0';
            this.txtTel.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.txtTel.SelectedText = "";
            this.txtTel.SelectionLength = 0;
            this.txtTel.SelectionStart = 0;
            this.txtTel.ShortcutsEnabled = true;
            this.txtTel.Size = new System.Drawing.Size(165, 23);
            this.txtTel.TabIndex = 10;
            this.txtTel.UseSelectable = true;
            this.txtTel.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.txtTel.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // dtpGiveBack
            // 
            this.dtpGiveBack.CustomFormat = "MM/dd/yyyy";
            this.dtpGiveBack.Location = new System.Drawing.Point(224, 209);
            this.dtpGiveBack.MinimumSize = new System.Drawing.Size(0, 29);
            this.dtpGiveBack.Name = "dtpGiveBack";
            this.dtpGiveBack.Size = new System.Drawing.Size(180, 29);
            this.dtpGiveBack.TabIndex = 11;
            // 
            // dtpOrder
            // 
            this.dtpOrder.CustomFormat = "MM/dd/yyyy";
            this.dtpOrder.Location = new System.Drawing.Point(224, 161);
            this.dtpOrder.MinimumSize = new System.Drawing.Size(0, 29);
            this.dtpOrder.Name = "dtpOrder";
            this.dtpOrder.Size = new System.Drawing.Size(180, 29);
            this.dtpOrder.TabIndex = 13;
            // 
            // metroLabel9
            // 
            this.metroLabel9.AutoSize = true;
            this.metroLabel9.Location = new System.Drawing.Point(56, 171);
            this.metroLabel9.Name = "metroLabel9";
            this.metroLabel9.Size = new System.Drawing.Size(105, 19);
            this.metroLabel9.TabIndex = 12;
            this.metroLabel9.Text = "Ngày đặt phòng";
            // 
            // metroLabel10
            // 
            this.metroLabel10.AutoSize = true;
            this.metroLabel10.Location = new System.Drawing.Point(56, 265);
            this.metroLabel10.Name = "metroLabel10";
            this.metroLabel10.Size = new System.Drawing.Size(102, 19);
            this.metroLabel10.TabIndex = 0;
            this.metroLabel10.Text = "Dịch vụ sử dụng";
            // 
            // metroLabel11
            // 
            this.metroLabel11.AutoSize = true;
            this.metroLabel11.Location = new System.Drawing.Point(442, 265);
            this.metroLabel11.Name = "metroLabel11";
            this.metroLabel11.Size = new System.Drawing.Size(55, 19);
            this.metroLabel11.TabIndex = 0;
            this.metroLabel11.Text = "Dịch vụ ";
            // 
            // cmbService
            // 
            this.cmbService.FormattingEnabled = true;
            this.cmbService.Location = new System.Drawing.Point(561, 263);
            this.cmbService.Name = "cmbService";
            this.cmbService.Size = new System.Drawing.Size(165, 21);
            this.cmbService.TabIndex = 14;
            // 
            // cmbServiceUsed
            // 
            this.cmbServiceUsed.FormattingEnabled = true;
            this.cmbServiceUsed.Location = new System.Drawing.Point(224, 263);
            this.cmbServiceUsed.Name = "cmbServiceUsed";
            this.cmbServiceUsed.Size = new System.Drawing.Size(180, 21);
            this.cmbServiceUsed.TabIndex = 14;
            // 
            // btnOrder
            // 
            this.btnOrder.Location = new System.Drawing.Point(617, 290);
            this.btnOrder.Name = "btnOrder";
            this.btnOrder.Size = new System.Drawing.Size(109, 23);
            this.btnOrder.TabIndex = 2;
            this.btnOrder.Text = "Đặt dịch vụ";
            this.btnOrder.UseSelectable = true;
            this.btnOrder.Click += new System.EventHandler(this.btnOrder_Click);
            // 
            // Form_QuanLiKhachHang
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(790, 580);
            this.Controls.Add(this.cmbServiceUsed);
            this.Controls.Add(this.cmbService);
            this.Controls.Add(this.dtpOrder);
            this.Controls.Add(this.metroLabel9);
            this.Controls.Add(this.dtpGiveBack);
            this.Controls.Add(this.txtTel);
            this.Controls.Add(this.txtPayments);
            this.Controls.Add(this.txtPeopleId);
            this.Controls.Add(this.txtName);
            this.Controls.Add(this.rdbFemale);
            this.Controls.Add(this.rdbMale);
            this.Controls.Add(this.metroLabel8);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.btnOrder);
            this.Controls.Add(this.metroButton2);
            this.Controls.Add(this.metroButton1);
            this.Controls.Add(this.metroLabel6);
            this.Controls.Add(this.metroLabel11);
            this.Controls.Add(this.metroLabel10);
            this.Controls.Add(this.metroLabel5);
            this.Controls.Add(this.txtClassroomId);
            this.Controls.Add(this.metroLabel4);
            this.Controls.Add(this.metroLabel3);
            this.Controls.Add(this.metroLabel2);
            this.Controls.Add(this.metroLabel7);
            this.Controls.Add(this.metroLabel1);
            this.Name = "Form_QuanLiKhachHang";
            this.Text = "Khách hàng";
            this.Load += new System.EventHandler(this.Form_QuanLiKhachHang_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private MetroFramework.Controls.MetroLabel metroLabel1;
        private MetroFramework.Controls.MetroButton metroButton1;
        private MetroFramework.Controls.MetroLabel metroLabel2;
        private MetroFramework.Controls.MetroLabel metroLabel3;
        private MetroFramework.Controls.MetroLabel metroLabel4;
        private MetroFramework.Controls.MetroTextBox txtClassroomId;
        private MetroFramework.Controls.MetroLabel metroLabel5;
        private MetroFramework.Controls.MetroLabel metroLabel6;
        private MetroFramework.Controls.MetroButton metroButton2;
        private System.Windows.Forms.DataGridView dataGridView1;
        private MetroFramework.Controls.MetroLabel metroLabel7;
        private MetroFramework.Controls.MetroRadioButton rdbFemale;
        private MetroFramework.Controls.MetroRadioButton rdbMale;
        private MetroFramework.Controls.MetroLabel metroLabel8;
        private MetroFramework.Controls.MetroTextBox txtName;
        private MetroFramework.Controls.MetroTextBox txtPeopleId;
        private MetroFramework.Controls.MetroTextBox txtPayments;
        private MetroFramework.Controls.MetroTextBox txtTel;
        private MetroFramework.Controls.MetroDateTime dtpGiveBack;
        private MetroFramework.Controls.MetroDateTime dtpOrder;
        private MetroFramework.Controls.MetroLabel metroLabel9;
        private MetroFramework.Controls.MetroLabel metroLabel10;
        private MetroFramework.Controls.MetroLabel metroLabel11;
        private System.Windows.Forms.ComboBox cmbService;
        private System.Windows.Forms.ComboBox cmbServiceUsed;
        private MetroFramework.Controls.MetroButton btnOrder;
    }
}