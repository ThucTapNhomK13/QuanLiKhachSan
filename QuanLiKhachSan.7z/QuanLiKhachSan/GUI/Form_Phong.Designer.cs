﻿namespace GUI
{
    partial class Form_Phong
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.metroLabel1 = new MetroFramework.Controls.MetroLabel();
            this.btnOrder = new MetroFramework.Controls.MetroButton();
            this.txtId = new MetroFramework.Controls.MetroTextBox();
            this.labStage = new MetroFramework.Controls.MetroLabel();
            this.txtStage = new MetroFramework.Controls.MetroTextBox();
            this.metroLabel2 = new MetroFramework.Controls.MetroLabel();
            this.txtClassify = new MetroFramework.Controls.MetroTextBox();
            this.label = new MetroFramework.Controls.MetroLabel();
            this.txtPrice = new MetroFramework.Controls.MetroTextBox();
            this.labUnit = new MetroFramework.Controls.MetroLabel();
            this.metroLabel3 = new MetroFramework.Controls.MetroLabel();
            this.rbdEnable = new MetroFramework.Controls.MetroRadioButton();
            this.rbdDisenable = new MetroFramework.Controls.MetroRadioButton();
            this.btnGiveBack = new MetroFramework.Controls.MetroButton();
            this.txtSerach = new MetroFramework.Controls.MetroTextBox();
            this.btnSearch = new MetroFramework.Controls.MetroButton();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.btnLoaddata = new MetroFramework.Controls.MetroButton();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // metroLabel1
            // 
            this.metroLabel1.AutoSize = true;
            this.metroLabel1.Location = new System.Drawing.Point(72, 85);
            this.metroLabel1.Name = "metroLabel1";
            this.metroLabel1.Size = new System.Drawing.Size(66, 19);
            this.metroLabel1.TabIndex = 1;
            this.metroLabel1.Text = "Số phòng";
            // 
            // btnOrder
            // 
            this.btnOrder.Location = new System.Drawing.Point(58, 215);
            this.btnOrder.Name = "btnOrder";
            this.btnOrder.Size = new System.Drawing.Size(75, 23);
            this.btnOrder.TabIndex = 2;
            this.btnOrder.Text = "Order";
            this.btnOrder.UseSelectable = true;
            this.btnOrder.Click += new System.EventHandler(this.btnOrder_Click);
            // 
            // txtId
            // 
            // 
            // 
            // 
            this.txtId.CustomButton.Image = null;
            this.txtId.CustomButton.Location = new System.Drawing.Point(62, 1);
            this.txtId.CustomButton.Name = "";
            this.txtId.CustomButton.Size = new System.Drawing.Size(21, 21);
            this.txtId.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.txtId.CustomButton.TabIndex = 1;
            this.txtId.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.txtId.CustomButton.UseSelectable = true;
            this.txtId.CustomButton.Visible = false;
            this.txtId.Lines = new string[0];
            this.txtId.Location = new System.Drawing.Point(157, 81);
            this.txtId.MaxLength = 32767;
            this.txtId.Name = "txtId";
            this.txtId.PasswordChar = '\0';
            this.txtId.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.txtId.SelectedText = "";
            this.txtId.SelectionLength = 0;
            this.txtId.SelectionStart = 0;
            this.txtId.ShortcutsEnabled = true;
            this.txtId.Size = new System.Drawing.Size(84, 23);
            this.txtId.TabIndex = 3;
            this.txtId.UseSelectable = true;
            this.txtId.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.txtId.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // labStage
            // 
            this.labStage.AutoSize = true;
            this.labStage.Location = new System.Drawing.Point(484, 89);
            this.labStage.Name = "labStage";
            this.labStage.Size = new System.Drawing.Size(38, 19);
            this.labStage.TabIndex = 1;
            this.labStage.Text = "Tầng";
            // 
            // txtStage
            // 
            // 
            // 
            // 
            this.txtStage.CustomButton.Image = null;
            this.txtStage.CustomButton.Location = new System.Drawing.Point(62, 1);
            this.txtStage.CustomButton.Name = "";
            this.txtStage.CustomButton.Size = new System.Drawing.Size(21, 21);
            this.txtStage.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.txtStage.CustomButton.TabIndex = 1;
            this.txtStage.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.txtStage.CustomButton.UseSelectable = true;
            this.txtStage.CustomButton.Visible = false;
            this.txtStage.Lines = new string[0];
            this.txtStage.Location = new System.Drawing.Point(540, 85);
            this.txtStage.MaxLength = 32767;
            this.txtStage.Name = "txtStage";
            this.txtStage.PasswordChar = '\0';
            this.txtStage.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.txtStage.SelectedText = "";
            this.txtStage.SelectionLength = 0;
            this.txtStage.SelectionStart = 0;
            this.txtStage.ShortcutsEnabled = true;
            this.txtStage.Size = new System.Drawing.Size(84, 23);
            this.txtStage.TabIndex = 3;
            this.txtStage.UseSelectable = true;
            this.txtStage.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.txtStage.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // metroLabel2
            // 
            this.metroLabel2.AutoSize = true;
            this.metroLabel2.Location = new System.Drawing.Point(268, 85);
            this.metroLabel2.Name = "metroLabel2";
            this.metroLabel2.Size = new System.Drawing.Size(75, 19);
            this.metroLabel2.TabIndex = 1;
            this.metroLabel2.Text = "Loại phòng";
            // 
            // txtClassify
            // 
            // 
            // 
            // 
            this.txtClassify.CustomButton.Image = null;
            this.txtClassify.CustomButton.Location = new System.Drawing.Point(62, 1);
            this.txtClassify.CustomButton.Name = "";
            this.txtClassify.CustomButton.Size = new System.Drawing.Size(21, 21);
            this.txtClassify.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.txtClassify.CustomButton.TabIndex = 1;
            this.txtClassify.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.txtClassify.CustomButton.UseSelectable = true;
            this.txtClassify.CustomButton.Visible = false;
            this.txtClassify.Lines = new string[0];
            this.txtClassify.Location = new System.Drawing.Point(353, 81);
            this.txtClassify.MaxLength = 32767;
            this.txtClassify.Name = "txtClassify";
            this.txtClassify.PasswordChar = '\0';
            this.txtClassify.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.txtClassify.SelectedText = "";
            this.txtClassify.SelectionLength = 0;
            this.txtClassify.SelectionStart = 0;
            this.txtClassify.ShortcutsEnabled = true;
            this.txtClassify.Size = new System.Drawing.Size(84, 23);
            this.txtClassify.TabIndex = 3;
            this.txtClassify.UseSelectable = true;
            this.txtClassify.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.txtClassify.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // label
            // 
            this.label.AutoSize = true;
            this.label.Location = new System.Drawing.Point(72, 138);
            this.label.Name = "label";
            this.label.Size = new System.Drawing.Size(28, 19);
            this.label.TabIndex = 1;
            this.label.Text = "Giá";
            // 
            // txtPrice
            // 
            // 
            // 
            // 
            this.txtPrice.CustomButton.Image = null;
            this.txtPrice.CustomButton.Location = new System.Drawing.Point(62, 1);
            this.txtPrice.CustomButton.Name = "";
            this.txtPrice.CustomButton.Size = new System.Drawing.Size(21, 21);
            this.txtPrice.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.txtPrice.CustomButton.TabIndex = 1;
            this.txtPrice.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.txtPrice.CustomButton.UseSelectable = true;
            this.txtPrice.CustomButton.Visible = false;
            this.txtPrice.Lines = new string[0];
            this.txtPrice.Location = new System.Drawing.Point(157, 134);
            this.txtPrice.MaxLength = 32767;
            this.txtPrice.Name = "txtPrice";
            this.txtPrice.PasswordChar = '\0';
            this.txtPrice.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.txtPrice.SelectedText = "";
            this.txtPrice.SelectionLength = 0;
            this.txtPrice.SelectionStart = 0;
            this.txtPrice.ShortcutsEnabled = true;
            this.txtPrice.Size = new System.Drawing.Size(84, 23);
            this.txtPrice.TabIndex = 3;
            this.txtPrice.UseSelectable = true;
            this.txtPrice.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.txtPrice.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // labUnit
            // 
            this.labUnit.AutoSize = true;
            this.labUnit.Location = new System.Drawing.Point(267, 138);
            this.labUnit.Name = "labUnit";
            this.labUnit.Size = new System.Drawing.Size(44, 19);
            this.labUnit.TabIndex = 1;
            this.labUnit.Text = " Ngày";
            // 
            // metroLabel3
            // 
            this.metroLabel3.AutoSize = true;
            this.metroLabel3.Location = new System.Drawing.Point(247, 138);
            this.metroLabel3.Name = "metroLabel3";
            this.metroLabel3.Size = new System.Drawing.Size(14, 19);
            this.metroLabel3.TabIndex = 1;
            this.metroLabel3.Text = "/";
            // 
            // rbdEnable
            // 
            this.rbdEnable.AutoSize = true;
            this.rbdEnable.Location = new System.Drawing.Point(353, 142);
            this.rbdEnable.Name = "rbdEnable";
            this.rbdEnable.Size = new System.Drawing.Size(71, 15);
            this.rbdEnable.TabIndex = 4;
            this.rbdEnable.Text = "Chưa đặt";
            this.rbdEnable.UseSelectable = true;
            // 
            // rbdDisenable
            // 
            this.rbdDisenable.AutoSize = true;
            this.rbdDisenable.Location = new System.Drawing.Point(455, 142);
            this.rbdDisenable.Name = "rbdDisenable";
            this.rbdDisenable.Size = new System.Drawing.Size(57, 15);
            this.rbdDisenable.TabIndex = 4;
            this.rbdDisenable.Text = "Đã đặt";
            this.rbdDisenable.UseSelectable = true;
            // 
            // btnGiveBack
            // 
            this.btnGiveBack.Location = new System.Drawing.Point(157, 215);
            this.btnGiveBack.Name = "btnGiveBack";
            this.btnGiveBack.Size = new System.Drawing.Size(75, 23);
            this.btnGiveBack.TabIndex = 2;
            this.btnGiveBack.Text = "Give back";
            this.btnGiveBack.UseSelectable = true;
            this.btnGiveBack.Click += new System.EventHandler(this.btnGiveBack_Click);
            // 
            // txtSerach
            // 
            // 
            // 
            // 
            this.txtSerach.CustomButton.Image = null;
            this.txtSerach.CustomButton.Location = new System.Drawing.Point(191, 1);
            this.txtSerach.CustomButton.Name = "";
            this.txtSerach.CustomButton.Size = new System.Drawing.Size(21, 21);
            this.txtSerach.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.txtSerach.CustomButton.TabIndex = 1;
            this.txtSerach.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.txtSerach.CustomButton.UseSelectable = true;
            this.txtSerach.CustomButton.Visible = false;
            this.txtSerach.Lines = new string[0];
            this.txtSerach.Location = new System.Drawing.Point(391, 215);
            this.txtSerach.MaxLength = 32767;
            this.txtSerach.Name = "txtSerach";
            this.txtSerach.PasswordChar = '\0';
            this.txtSerach.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.txtSerach.SelectedText = "";
            this.txtSerach.SelectionLength = 0;
            this.txtSerach.SelectionStart = 0;
            this.txtSerach.ShortcutsEnabled = true;
            this.txtSerach.Size = new System.Drawing.Size(213, 23);
            this.txtSerach.TabIndex = 3;
            this.txtSerach.UseSelectable = true;
            this.txtSerach.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.txtSerach.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // btnSearch
            // 
            this.btnSearch.Location = new System.Drawing.Point(619, 215);
            this.btnSearch.Name = "btnSearch";
            this.btnSearch.Size = new System.Drawing.Size(75, 23);
            this.btnSearch.TabIndex = 2;
            this.btnSearch.Text = "Search";
            this.btnSearch.UseSelectable = true;
            this.btnSearch.Click += new System.EventHandler(this.btnSearch_Click);
            // 
            // dataGridView1
            // 
            this.dataGridView1.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridView1.BackgroundColor = System.Drawing.SystemColors.ButtonHighlight;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.GridColor = System.Drawing.SystemColors.ButtonHighlight;
            this.dataGridView1.Location = new System.Drawing.Point(38, 260);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(656, 199);
            this.dataGridView1.TabIndex = 5;
            this.dataGridView1.Click += new System.EventHandler(this.dataGridView1_Click);
            // 
            // btnLoaddata
            // 
            this.btnLoaddata.Location = new System.Drawing.Point(256, 215);
            this.btnLoaddata.Name = "btnLoaddata";
            this.btnLoaddata.Size = new System.Drawing.Size(75, 23);
            this.btnLoaddata.TabIndex = 2;
            this.btnLoaddata.Text = "Load data";
            this.btnLoaddata.UseSelectable = true;
            this.btnLoaddata.Click += new System.EventHandler(this.btnLoaddata_Click);
            // 
            // Form_Phong
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(741, 482);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.rbdDisenable);
            this.Controls.Add(this.rbdEnable);
            this.Controls.Add(this.txtStage);
            this.Controls.Add(this.txtPrice);
            this.Controls.Add(this.txtClassify);
            this.Controls.Add(this.txtSerach);
            this.Controls.Add(this.txtId);
            this.Controls.Add(this.metroLabel3);
            this.Controls.Add(this.labUnit);
            this.Controls.Add(this.label);
            this.Controls.Add(this.labStage);
            this.Controls.Add(this.metroLabel2);
            this.Controls.Add(this.btnSearch);
            this.Controls.Add(this.btnLoaddata);
            this.Controls.Add(this.btnGiveBack);
            this.Controls.Add(this.btnOrder);
            this.Controls.Add(this.metroLabel1);
            this.Name = "Form_Phong";
            this.Text = "Đặt phòng";
            this.Load += new System.EventHandler(this.Form_Phong_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private MetroFramework.Controls.MetroLabel metroLabel1;
        private MetroFramework.Controls.MetroButton btnOrder;
        private MetroFramework.Controls.MetroTextBox txtId;
        private MetroFramework.Controls.MetroLabel labStage;
        private MetroFramework.Controls.MetroTextBox txtStage;
        private MetroFramework.Controls.MetroLabel metroLabel2;
        private MetroFramework.Controls.MetroTextBox txtClassify;
        private MetroFramework.Controls.MetroLabel label;
        private MetroFramework.Controls.MetroTextBox txtPrice;
        private MetroFramework.Controls.MetroLabel labUnit;
        private MetroFramework.Controls.MetroLabel metroLabel3;
        private MetroFramework.Controls.MetroRadioButton rbdEnable;
        private MetroFramework.Controls.MetroRadioButton rbdDisenable;
        private MetroFramework.Controls.MetroButton btnGiveBack;
        private MetroFramework.Controls.MetroTextBox txtSerach;
        private MetroFramework.Controls.MetroButton btnSearch;
        private System.Windows.Forms.DataGridView dataGridView1;
        private MetroFramework.Controls.MetroButton btnLoaddata;
    }
}